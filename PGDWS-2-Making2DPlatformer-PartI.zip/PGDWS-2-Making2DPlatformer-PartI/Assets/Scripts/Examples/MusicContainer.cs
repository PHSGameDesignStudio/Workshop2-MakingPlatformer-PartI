﻿using UnityEngine;
public class MusicContainer : MonoBehaviour
{
    public AudioClip clip;
}
