﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public float speed, jumpForce, gravity;
    bool isGrounded;
    Rigidbody2D rb;
    Animator anim;
    SpriteRenderer imgrenderer;
    public Camera cam;
    public bool FlipWithSpriteRenderer = true;
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
        imgrenderer = GetComponent<SpriteRenderer>();
    }

    void Update()
    {
        #region Input

        // Moves the character along the X-axis when the right/left arrow key is pressed
        rb.position += Input.GetAxisRaw("Horizontal") * Vector2.right * speed * Time.deltaTime;

        // Allows the player to jump when the up arrow is pressed and the player's feet is on the ground
        if (Input.GetKeyDown(KeyCode.UpArrow) && isGrounded)
            rb.velocity = new Vector2(rb.velocity.x, jumpForce);
        
        // We dont have to worry about gravity since this is a Dynamic Rigidbody, Not Kinematic.
        #endregion

        #region Animation

        /* Heres code for flipping Sprite axis when moving the opposite direction (if the arrow keys are pressed)
        We have two options: flip with scale or flip with spriteRenderer. Both options are here coded */
        if (FlipWithSpriteRenderer) 
        {
            if (Input.GetAxisRaw("Horizontal") != 0) 
                imgrenderer.flipX = Input.GetAxisRaw("Horizontal") < 0;
        }
        else 
        {
            if (Input.GetAxisRaw("Horizontal") != 0) 
                if (Input.GetAxisRaw("Horizontal") < 0) {
                    transform.localScale = new Vector3(-Mathf.Abs(transform.localScale.x), transform.localScale.y, transform.localScale.z);
                } else {
                    transform.localScale = new Vector3(Mathf.Abs(transform.localScale.x), transform.localScale.y, transform.localScale.z);
                }
        }
        

        // If the player isnt grounded we can assume the player is jumping.
        anim.SetBool("isJumping", !isGrounded);

        // If the player isnt jumping however it is moving on the X axis (isnt pressing right or left key) we can assume the player is walking
        anim.SetBool("isWalking", (Input.GetAxisRaw("Horizontal") != 0));

        // If the player isn't jumping or walking we can assume the player is idle.

        #endregion

        // Moves camera with player.
        cam.gameObject.transform.position = new Vector3(transform.position.x, transform.position.y, cam.gameObject.transform.position.z);
        
        SFX(); // Music stuff
    
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Ground")
        {
            isGrounded = true;
            print("COLLIDED YAY!");
        }
        if (collision.gameObject.tag == "MusicTrigger") {
            // play music from script
        }
    }
    private void OnCollisionExit2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Ground")
            isGrounded = false;
    }

    #region Music & SFX
    public AudioSource musicSource;
    public AudioSource sfxJumpSource;
    public AudioClip sfxJumpClip;
    public AudioSource sfxWalkSource;
    public AudioClip sfxWalkClip;
    void ResetAudioPlayer(AudioSource audioPlayer) {
        audioPlayer.enabled = false;
        audioPlayer.enabled = true;
    }
    private void OnTriggerEnter2D(Collider2D collider) {
        if (collider.tag == "Music") {
            musicSource.clip = collider.GetComponent<MusicContainer>().clip;
            ResetAudioPlayer(musicSource);
        }
    }
    void SFX() {
        sfxJumpSource.enabled = anim.GetBool("isJumping"); // This source plays our jump sfx when the player is jumping
        sfxWalkSource.enabled = (anim.GetBool("isWalking") && !anim.GetBool("isJumping")); // This source plays our walking sfx when the player is walking & not jumping.\
        /* Psuedo Code 

        if jumping then jumping sfx is = true
        else jumping sfx is = false
        
        if walking and not jumping then walking sfx is = true
        else walking sfx is = false
        */
    }
    
    #endregion
    
}
